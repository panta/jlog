# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_jlog_global_optspecs
    string join \n web no-open port= columns= level= plain= no-color time-format= utc manual man h/help V/version
end

function __fish_jlog_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_jlog_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_jlog_using_subcommand
    set -l cmd (__fish_jlog_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c jlog -n "__fish_jlog_needs_command" -l port -d 'With --web: TCP port on 127.0.0.1 (0 = random free port)' -r
complete -c jlog -n "__fish_jlog_needs_command" -l columns -d 'Initial visible columns, comma separated (time, level, message or field paths)' -r
complete -c jlog -n "__fish_jlog_needs_command" -l level -d 'Initial level filter: `warn` shows WARN and above, `=warn` shows only WARN' -r
complete -c jlog -n "__fish_jlog_needs_command" -l plain -d 'Noninteractive output to stdout (default when stdout is not a terminal: jsonl)' -r -f -a "jsonl\t'Original lines, unchanged'
table\t'Aligned text columns without colors or escape sequences'"
complete -c jlog -n "__fish_jlog_needs_command" -l time-format -d 'strftime pattern for the time column' -r
complete -c jlog -n "__fish_jlog_needs_command" -l web -d 'Serve a browser UI on 127.0.0.1 instead of the terminal viewer'
complete -c jlog -n "__fish_jlog_needs_command" -l no-open -d 'With --web: print the URL but do not launch a browser'
complete -c jlog -n "__fish_jlog_needs_command" -l no-color -d 'Disable colors and text styling (also honored via the NO_COLOR environment variable)'
complete -c jlog -n "__fish_jlog_needs_command" -l utc -d 'Show times in UTC instead of the local timezone'
complete -c jlog -n "__fish_jlog_needs_command" -l manual -d 'Same as `jlog manual` (kept for compatibility)'
complete -c jlog -n "__fish_jlog_needs_command" -l man -d 'Same as `jlog man` (kept for compatibility)'
complete -c jlog -n "__fish_jlog_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c jlog -n "__fish_jlog_needs_command" -s V -l version -d 'Print version'
complete -c jlog -n "__fish_jlog_needs_command" -a "send" -d 'Offer FILE to one other jlog user: prints a ticket, then waits for the receiver'
complete -c jlog -n "__fish_jlog_needs_command" -a "receive" -d 'Fetch the file a ticket points to: opens it in the viewer while it downloads, or writes it to -o PATH (or to stdout when stdout is not a terminal)'
complete -c jlog -n "__fish_jlog_needs_command" -a "man" -d 'Show the manual page (formatted on a terminal, roff source when redirected)'
complete -c jlog -n "__fish_jlog_needs_command" -a "manual" -d 'Show the complete manual as plain text'
complete -c jlog -n "__fish_jlog_needs_command" -a "version" -d 'Print the version (same as --version)'
complete -c jlog -n "__fish_jlog_needs_command" -a "ver" -d 'Print the version (same as --version)'
complete -c jlog -n "__fish_jlog_needs_command" -a "vers" -d 'Print the version (same as --version)'
complete -c jlog -n "__fish_jlog_needs_command" -a "completions" -d 'Print a shell completion script (see the manual for where to install it)'
complete -c jlog -n "__fish_jlog_needs_command" -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c jlog -n "__fish_jlog_using_subcommand send" -l expire -d 'Stop waiting for a receiver after this long (e.g. 90s, 15m, 2h)' -r
complete -c jlog -n "__fish_jlog_using_subcommand send" -l relay -d 'Relay URL (default: https://relay.logging.work, or $JLOG_RELAY; `none` = direct only)' -r
complete -c jlog -n "__fish_jlog_using_subcommand send" -l relay-only -d 'Connect through the relay only: no direct paths, no IP addresses in the ticket'
complete -c jlog -n "__fish_jlog_using_subcommand send" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand receive" -s o -l output -d 'Save the file to PATH instead of opening it (never overwrites an existing file)' -r -F
complete -c jlog -n "__fish_jlog_using_subcommand receive" -l relay -d 'Relay URL (default: https://relay.logging.work, or $JLOG_RELAY; `none` = direct only)' -r
complete -c jlog -n "__fish_jlog_using_subcommand receive" -l no-auto-relay -d 'Keep a slow direct path instead of switching to the relay when that is faster'
complete -c jlog -n "__fish_jlog_using_subcommand receive" -l relay-only -d 'Connect through the relay only: no direct paths, no IP addresses in the ticket'
complete -c jlog -n "__fish_jlog_using_subcommand receive" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand man" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand manual" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand version" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand ver" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand vers" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand completions" -s h -l help -d 'Print help'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "send" -d 'Offer FILE to one other jlog user: prints a ticket, then waits for the receiver'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "receive" -d 'Fetch the file a ticket points to: opens it in the viewer while it downloads, or writes it to -o PATH (or to stdout when stdout is not a terminal)'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "man" -d 'Show the manual page (formatted on a terminal, roff source when redirected)'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "manual" -d 'Show the complete manual as plain text'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "version" -d 'Print the version (same as --version)'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "completions" -d 'Print a shell completion script (see the manual for where to install it)'
complete -c jlog -n "__fish_jlog_using_subcommand help; and not __fish_seen_subcommand_from send receive man manual version completions help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
