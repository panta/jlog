# jlog

A small, fast, read-only pager for JSON Lines logs (JSONL / NDJSON), shipped as one
native executable per platform.

`jlog` opens a file, a pipe, or a file picker and shows each log record as a table row.
It recognizes time, level and message fields automatically, so zerolog, zap, logrus,
slog, pino and similar output looks right without configuration. It never modifies its
input.

> Status: 0.2.1. Terminal viewer, local browser UI and peer-to-peer transfer are complete; see
> `docs/ACCEPTANCE.md` for verified platforms and known gaps.

## Install

Release archives for Linux, macOS and Windows are published with `SHA256SUMS` on the
download site (see `docs/RELEASING.md`). On Linux and macOS the site's `install.sh`
downloads, verifies and installs the binary into `~/.local/bin`, with the man page, shell
completions (bash, zsh, fish) and license notices under `~/.local/share`. On Windows,
`irm https://jlog.logging.work/install.ps1 | iex` verifies and installs `jlog.exe` into
`%LOCALAPPDATA%\Programs\jlog` and adds it to the user `PATH` (`-NoPath`, `-Minimal`,
`-Completions` via `& ([scriptblock]::Create((irm .../install.ps1))) -Minimal`).

Each platform has two builds: the standard one, and a **minimal** one without `jlog send` /
`jlog receive` that makes no network connections at all (`install.sh --minimal`,
`jlog --version` says which one is installed). Build the minimal variant from source with
`make MINIMAL=1 build` or `cargo build --release --no-default-features`.

## Build

Requires Rust 1.97 or newer.

```sh
cargo build --release
./target/release/jlog --help
```

With `make` (`make help` lists every target):

```sh
make build                 # release build for this machine: target/release/jlog
make install               # into ~/.local/bin, man page into ~/.local/share/man/man1
make install PREFIX=/usr/local
make build-macos-all       # Apple silicon + Intel, plus a universal binary (lipo)
```

The Intel and Apple silicon builds land in `target/<triple>/release/jlog`, the universal
binary in `target/universal-apple-darwin/release/jlog`.

## Quick start

```sh
jlog app.jsonl                     # open a file
jlog                               # pick a file in the current directory
kubectl logs deploy/api | jlog     # page piped logs; the keyboard still works
journalctl -o json -u nginx | jlog
jlog app.jsonl | grep timeout      # stdout is not a terminal: raw JSONL passthrough
jlog --plain=table app.jsonl       # aligned text table without escape codes
jlog --columns time,level,message,service app.jsonl
jlog --time-format '%H:%M:%S%.3f' --utc app.jsonl
```

On Windows the same commands work in Windows Terminal, PowerShell and `cmd.exe`
(for example `Get-Content app.jsonl | jlog`).

## Columns

Default columns, left to right, when the fields are present:

| Column | Source fields (case-insensitive, first match wins) |
|---|---|
| TIME | `time`, `ts`, `timestamp`, `@timestamp`, `datetime`, `date` |
| LEVEL | `level`, `lvl`, `severity`, `severity_text`, `loglevel`, `log.level` |
| COMPONENT, METHOD, URL | `component`, `method`, `url` |
| MESSAGE | `message`, `msg`, `text`, `event` |
| others | the most common short fields, such as `service`, `caller`, `request_id` |

Times are shown as `2026-10-15 12:00:00 +0200` in the local timezone by default
(`--time-format` takes a strftime pattern, `--utc` switches to UTC). RFC 3339 strings and
Unix epochs in seconds, milliseconds, microseconds or nanoseconds are recognized.

Levels are normalized to TRACE, DEBUG, INFO, WARN, ERROR, FATAL and PANIC; accepted
spellings include `dbg`, `inf`, `msg`, `warning`, `wrn`, `err`, `ftl` and the numeric pino
levels 10-60.

## Browser mode

```sh
jlog --web app.jsonl            # serves on 127.0.0.1 and opens the browser
jlog --web --no-open app.jsonl  # just print the URL
```

The page offers the same filters, search, selection, copy and export as the terminal,
plus mouse selection (click, Shift+click ranges, Ctrl/Cmd+click marks) and resizable
columns. The URL contains a secret session token: do not share it. Ctrl+C stops the server.

## Sending a log to someone

```sh
jlog send app.jsonl                 # prints a ticket and waits for one receiver
jlog receive jlog1...               # on the other machine: view while it downloads
jlog receive jlog1... -o app.jsonl  # or save it (never overwrites)
```

Not in the minimal build. The transfer is end-to-end encrypted and direct when
possible, otherwise through the jlog relay `relay.logging.work`, which cannot read it. The
ticket is a one-time capability: share it only with the intended receiver. `--relay-only`
keeps your IP addresses out of the ticket. No other jlog command uses the network.

## Search and filters

- `/timeout` searches the whole original line (including fields not shown), ignoring case.
- `/service:payments` searches one field; `/request.id:abc` a nested field. `time`, `level`
  and `message` also match their recognized aliases (`/message:refused` finds `msg`).
- Escape a literal colon or dot with a backslash: `/http\:500`, `/request\.id:abc`.
- `n`/`N` jump to the next/previous match; `M` hides rows that do not match.
- `f` filters on a field (`service:api`); `1`/`2`/`3` show all, WARN+ or ERROR+; `L` picks any
  level and `=` switches between "at least" and "exactly". From the command line:
  `--level warn` or `--level =warn`.
- Filters keep source order and physical line numbers; the status bar shows the number of
  matching rows once counting has finished (`≥N` while it is still counting).

## Selection, copy and export

- `Space` marks rows, `v` selects a range, `Ctrl+A` selects every row of the current view
  (a frozen snapshot: later filter changes do not alter it), `u` clears.
- `y` copies the original lines in file order (up to 10 MiB). Over SSH jlog uses the
  terminal's OSC 52 clipboard and tells you when delivery cannot be confirmed.
- `e` exports the selection or the current view as JSONL (byte-exact), JSON, CSV or a
  standalone HTML page. Files are written atomically and never replace the source.

## Keys

Log viewer

| Key | Action |
|---|---|
| Up/Down, k/j | Move focused row |
| Left/Right, h/l | Scroll columns horizontally |
| PageUp/PageDown, Ctrl+B | Move one page |
| Home/End, g/G | First/last row |
| Ctrl+G, :N | Go to physical line N |
| /, Ctrl+F | Search text, or field:text |
| n/N, F3/Shift+F3 | Next/previous match |
| M | Show only matching rows (toggle) |
| f | Field filter field:text (empty clears) |
| 1, 2, 3 | Level filter: all, WARN+, ERROR+ |
| L | Choose the level filter |
| = | Level filter: at least / exactly |
| Enter | Open record detail |
| Space | Mark or unmark the row |
| v | Start/finish a range selection |
| Shift+Up/Down | Extend a range selection |
| Ctrl+A | Select all rows of the current view |
| u | Clear the selection |
| y | Copy selected (or focused) lines |
| c | Column chooser |
| e | Export dialog |
| R | Re-sample the file and refresh default columns |
| o | Open another file |
| ?, F1 | Help |
| Esc | Close prompt; cancel range, scan or export |
| q | Quit |

Record detail

| Key | Action |
|---|---|
| Up/Down, k/j | Scroll |
| Left/Right, h/l | Scroll horizontally |
| PageUp/PageDown | Scroll one page |
| Home/End, g/G | Top/bottom |
| Esc, q | Back to the table |

Column chooser

| Key | Action |
|---|---|
| Up/Down, k/j | Move cursor |
| Space | Show or hide the column |
| K/J | Move the column up/down |
| Enter | Apply |
| Esc | Cancel |

File picker

| Key | Action |
|---|---|
| Up/Down, k/j | Move cursor |
| PageUp/PageDown | Move one page |
| Home/End, g/G | First/last entry |
| Enter | Open directory or file |
| Backspace | Parent directory |
| / | Filter file names |
| Ctrl+L | Type a path |
| Esc, q | Quit (or back to the viewer) |

Browser (`--web`)

| Key | Action |
|---|---|
| Up/Down, k/j | Move focused row |
| PageUp/PageDown, Home/End | Move one page / first or last row |
| Enter, double-click | Record detail |
| Space, Ctrl/Cmd+click | Mark or unmark the row |
| v, Shift+click, Shift+Up/Down | Range selection |
| Ctrl+A | Select all rows of the current view |
| u | Clear the selection |
| / | Search box (Ctrl+F too, when the browser allows it) |
| n/N, F3/Shift+F3 | Next/previous match |
| M | Show only matching rows (toggle) |
| f | Field filter box |
| 1, 2, 3, L, = | Level filter: all, WARN+, ERROR+, choose, mode |
| :, Ctrl+G | Go to physical line |
| y | Copy selected (or focused) lines |
| e | Export (download) |
| c | Columns |
| ? | Help |
| Esc | Close a panel or cancel a range |

## Behavior worth knowing

- **Files are snapshots.** Data appended after opening is not shown; jlog tells you the
  file grew. Truncation or replacement is reported as a stale view.
- **Pipes are spooled** to a private temporary file (deleted on exit) so you can scroll
  back. Only complete lines are shown until the input ends.
- **Malformed lines stay visible**, marked `INVALID JSON` or `NON-OBJECT`. Lines over 8 MiB
  are shown as `OVERSIZED` previews.
- **Untrusted text is neutralized:** control characters, terminal escape sequences and
  bidirectional-text controls are shown as visible escapes such as `\e` or `<U+202E>`.
- **No network access** except the optional `--web` server, which listens on `127.0.0.1`
  only, behind a random per-run token, and rejects other Host/Origin values.

Run `jlog man` for the manual page (formatted with `man` on Linux and macOS, roff source when
redirected) or `jlog manual` for the same text without formatting (also on Windows).

## License

jlog is licensed under the Server Side Public License, version 1 (SSPL-1.0). See
[LICENSE](LICENSE).
