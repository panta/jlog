
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'jlog' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'jlog'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'jlog' {
            [CompletionResult]::new('--port', '--port', [CompletionResultType]::ParameterName, 'With --web: TCP port on 127.0.0.1 (0 = random free port)')
            [CompletionResult]::new('--columns', '--columns', [CompletionResultType]::ParameterName, 'Initial visible columns, comma separated (time, level, message or field paths)')
            [CompletionResult]::new('--level', '--level', [CompletionResultType]::ParameterName, 'Initial level filter: `warn` shows WARN and above, `=warn` shows only WARN')
            [CompletionResult]::new('--plain', '--plain', [CompletionResultType]::ParameterName, 'Noninteractive output to stdout (default when stdout is not a terminal: jsonl)')
            [CompletionResult]::new('--time-format', '--time-format', [CompletionResultType]::ParameterName, 'strftime pattern for the time column')
            [CompletionResult]::new('--web', '--web', [CompletionResultType]::ParameterName, 'Serve a browser UI on 127.0.0.1 instead of the terminal viewer')
            [CompletionResult]::new('--no-open', '--no-open', [CompletionResultType]::ParameterName, 'With --web: print the URL but do not launch a browser')
            [CompletionResult]::new('--no-color', '--no-color', [CompletionResultType]::ParameterName, 'Disable colors and text styling (also honored via the NO_COLOR environment variable)')
            [CompletionResult]::new('--utc', '--utc', [CompletionResultType]::ParameterName, 'Show times in UTC instead of the local timezone')
            [CompletionResult]::new('--manual', '--manual', [CompletionResultType]::ParameterName, 'Same as `jlog manual` (kept for compatibility)')
            [CompletionResult]::new('--man', '--man', [CompletionResultType]::ParameterName, 'Same as `jlog man` (kept for compatibility)')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('-V', '-V ', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('--version', '--version', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('send', 'send', [CompletionResultType]::ParameterValue, 'Offer FILE to one other jlog user: prints a ticket, then waits for the receiver')
            [CompletionResult]::new('receive', 'receive', [CompletionResultType]::ParameterValue, 'Fetch the file a ticket points to: opens it in the viewer while it downloads, or writes it to -o PATH (or to stdout when stdout is not a terminal)')
            [CompletionResult]::new('man', 'man', [CompletionResultType]::ParameterValue, 'Show the manual page (formatted on a terminal, roff source when redirected)')
            [CompletionResult]::new('manual', 'manual', [CompletionResultType]::ParameterValue, 'Show the complete manual as plain text')
            [CompletionResult]::new('version', 'version', [CompletionResultType]::ParameterValue, 'Print the version (same as --version)')
            [CompletionResult]::new('ver', 'ver', [CompletionResultType]::ParameterValue, 'Print the version (same as --version)')
            [CompletionResult]::new('vers', 'vers', [CompletionResultType]::ParameterValue, 'Print the version (same as --version)')
            [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Print a shell completion script (see the manual for where to install it)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'jlog;send' {
            [CompletionResult]::new('--expire', '--expire', [CompletionResultType]::ParameterName, 'Stop waiting for a receiver after this long (e.g. 90s, 15m, 2h)')
            [CompletionResult]::new('--relay', '--relay', [CompletionResultType]::ParameterName, 'Relay URL (default: https://relay.logging.work, or $JLOG_RELAY; `none` = direct only)')
            [CompletionResult]::new('--relay-only', '--relay-only', [CompletionResultType]::ParameterName, 'Connect through the relay only: no direct paths, no IP addresses in the ticket')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;receive' {
            [CompletionResult]::new('-o', '-o', [CompletionResultType]::ParameterName, 'Save the file to PATH instead of opening it (never overwrites an existing file)')
            [CompletionResult]::new('--output', '--output', [CompletionResultType]::ParameterName, 'Save the file to PATH instead of opening it (never overwrites an existing file)')
            [CompletionResult]::new('--relay', '--relay', [CompletionResultType]::ParameterName, 'Relay URL (default: https://relay.logging.work, or $JLOG_RELAY; `none` = direct only)')
            [CompletionResult]::new('--no-auto-relay', '--no-auto-relay', [CompletionResultType]::ParameterName, 'Keep a slow direct path instead of switching to the relay when that is faster')
            [CompletionResult]::new('--relay-only', '--relay-only', [CompletionResultType]::ParameterName, 'Connect through the relay only: no direct paths, no IP addresses in the ticket')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;man' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;manual' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;version' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;ver' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;vers' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;completions' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'jlog;help' {
            [CompletionResult]::new('send', 'send', [CompletionResultType]::ParameterValue, 'Offer FILE to one other jlog user: prints a ticket, then waits for the receiver')
            [CompletionResult]::new('receive', 'receive', [CompletionResultType]::ParameterValue, 'Fetch the file a ticket points to: opens it in the viewer while it downloads, or writes it to -o PATH (or to stdout when stdout is not a terminal)')
            [CompletionResult]::new('man', 'man', [CompletionResultType]::ParameterValue, 'Show the manual page (formatted on a terminal, roff source when redirected)')
            [CompletionResult]::new('manual', 'manual', [CompletionResultType]::ParameterValue, 'Show the complete manual as plain text')
            [CompletionResult]::new('version', 'version', [CompletionResultType]::ParameterValue, 'Print the version (same as --version)')
            [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Print a shell completion script (see the manual for where to install it)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'jlog;help;send' {
            break
        }
        'jlog;help;receive' {
            break
        }
        'jlog;help;man' {
            break
        }
        'jlog;help;manual' {
            break
        }
        'jlog;help;version' {
            break
        }
        'jlog;help;completions' {
            break
        }
        'jlog;help;help' {
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
